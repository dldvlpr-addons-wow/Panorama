-- Panorama : liste des réglages, sauvegarde et écriture des CVars.
-- Le panneau d'options est dans Options.lua.
local addonName, NS = ...

-- Une ligne sans `cvar` est un titre de section.
-- Les bornes min/max sont celles des menus du jeu : le panneau ne permet pas d'en sortir,
-- et une valeur hors bornes dans PanoramaDB (fichier édité à la main) est ramenée dedans.
-- Une CVar inconnue du client est ignorée : ni affichée, ni écrite.
NS.settings = {
    { title = "Distance d'affichage" },
    { cvar = "farclip", label = "Distance des décors", min = 185, max = 2600, step = 5, default = 1300,
      tip = "Distance d'affichage maximale des décors et structures." },
    { cvar = "horizonfarclip", label = "Distance de l'horizon", min = 1000, max = 5000, step = 16, default = 2112,
      tip = "Distance d'affichage de la ligne d'horizon et du relief." },
    { cvar = "volumeFog", label = "Brouillard volumétrique", default = false,
      tip = "Décoché : supprime le brouillard pour une clarté totale." },

    { title = "Végétation et détails" },
    { cvar = "detailDoodleDensity", label = "Détails au sol", min = 0, max = 100, step = 1, default = 100,
      tip = "Densité des petits détails au sol." },
    { cvar = "groundEffectDensity", label = "Densité de l'herbe", min = 16, max = 256, step = 8, default = 256,
      tip = "Densité de l'herbe et de la végétation." },
    { cvar = "groundEffectDist", label = "Distance de l'herbe", min = 0, max = 300, step = 5, default = 140,
      tip = "Distance de visibilité de la végétation." },

    { title = "Ombres et lumière" },
    { cvar = "shadowLevel", label = "Qualité des ombres", min = 0, max = 2, step = 1, default = 2,
      tip = "Qualité des ombres portées." },
    { cvar = "shadowSoft", label = "Ombres adoucies", default = true,
      tip = "Adoucissement réaliste des bords d'ombres." },
    { cvar = "shadowTextureSize", label = "Résolution des ombres", choices = { 1024, 2048 }, default = 2048,
      tip = "Résolution des cartes d'ombres." },
    { cvar = "sunShafts", label = "Rayons de soleil", min = 0, max = 2, step = 1, default = 2,
      tip = "Rayons de soleil à travers le décor (God Rays)." },
    { cvar = "SSAO", label = "Occlusion ambiante", min = 0, max = 3, step = 1, default = 3,
      tip = "Ombres de contact réalistes (SSAO)." },
    { cvar = "SSFX", label = "Effets d'écran", default = true,
      tip = "Post-traitement avancé (Screen Space Effects)." },

    { title = "Environnement" },
    { cvar = "waterDetail", label = "Détail de l'eau", min = 0, max = 3, step = 1, default = 3,
      tip = "Physique et reflets de l'eau." },
    { cvar = "skyCloudLod", label = "Détail du ciel", min = 0, max = 3, step = 1, default = 3,
      tip = "Rendu des nuages et du ciel." },
    { cvar = "WeatherDensity", label = "Intensité météo", min = 0, max = 3, step = 1, default = 3,
      tip = "Intensité des effets météo (pluie, neige)." },
    { cvar = "physicsLevel", label = "Physique", min = 0, max = 2, step = 1, default = 2,
      tip = "Interaction des objets et des tissus." },

    { title = "Image" },
    { cvar = "gxMultisample", label = "Anticrénelage (MSAA)", choices = { 1, 2, 4, 8 }, default = 8,
      tip = "Lissage des contours. Prend effet après redémarrage du moteur graphique." },
    { cvar = "ResampleAlwaysSharpen", label = "Filtre de netteté", default = true,
      tip = "Filtre de netteté de l'image." },
    { cvar = "ResampleSharpness", label = "Intensité de la netteté", min = 0, max = 2, step = 0.1, default = 0.5,
      tip = "Force du filtre de netteté, quand il est activé." },
    { cvar = "ffxGlow", label = "Lueur plein écran", default = true,
      tip = "Effet de lueur (bloom) sur les sources de lumière." },
    { cvar = "ffxDeath", label = "Écran gris à la mort", default = false,
      tip = "Décoché : pas de filtre gris quand ton personnage meurt." },
    { cvar = "violenceLevel", label = "Niveau de violence", min = 0, max = 5, step = 1, default = 5,
      tip = "Sang et effets d'impact." },
    { cvar = "ProjectedTextures", label = "Textures projetées", default = true,
      tip = "Rendu des textures projetées au sol (sorts, effets)." },
    { cvar = "spellClutter", label = "Alléger les sorts", default = false,
      tip = "Décoché : conserve l'intégralité du rendu visuel des sorts." },

    { title = "Caméra, souris et interface" },
    { cvar = "cameraDistanceMaxZoomFactor", label = "Recul de la caméra", min = 1, max = 2.6, step = 0.1, default = 2.6,
      tip = "Recul maximal de la caméra." },
    -- Maximum imposé par le client : 60 sur retail, 41 sur les clients Classic.
    { cvar = "nameplateMaxDistance", label = "Distance des barres de nom", min = 20,
      max = (WOW_PROJECT_ID == WOW_PROJECT_MAINLINE) and 60 or 41, step = 1, default = 41,
      tip = "Distance à laquelle les barres de nom des unités s'affichent." },
    { cvar = "rawMouseEnable", label = "Souris brute", default = true,
      tip = "Ignore l'accélération de la souris de Windows." },
    { cvar = "screenshotQuality", label = "Qualité des captures", min = 1, max = 10, step = 1, default = 10,
      tip = "Qualité des captures d'écran." },
    { cvar = "scriptErrors", label = "Afficher les erreurs Lua", default = false,
      tip = "Décoché : les erreurs de script ne s'affichent plus à l'écran." },
}

local function GetCVarValue(name)
    if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar(name) end
    return GetCVar(name)
end

local function SetCVarValue(name, value)
    if C_CVar and C_CVar.SetCVar then return C_CVar.SetCVar(name, value) end
    return SetCVar(name, value)
end

function NS.Exists(setting)
    return GetCVarValue(setting.cvar) ~= nil
end

-- Ramène une valeur lue dans PanoramaDB dans les limites du réglage.
function NS.Sanitize(setting, value)
    if type(setting.default) == "boolean" then
        if type(value) ~= "boolean" then return setting.default end
        return value
    end
    if type(value) ~= "number" or value ~= value then return setting.default end
    if setting.choices then
        for _, choice in ipairs(setting.choices) do
            if choice == value then return value end
        end
        return setting.default
    end
    return math.min(setting.max, math.max(setting.min, value))
end

local pending = false
local events = CreateFrame("Frame")

function NS.Apply(setting)
    if not NS.Exists(setting) then return end
    -- Certaines CVars refusent l'écriture en combat : tout est réappliqué à la sortie du combat.
    if InCombatLockdown() then
        pending = true
        events:RegisterEvent("PLAYER_REGEN_ENABLED")
        return
    end
    local value = NS.db.values[setting.cvar]
    if type(value) == "boolean" then value = value and 1 or 0 end
    SetCVarValue(setting.cvar, tostring(value))
end

function NS.ApplyAll()
    for _, setting in ipairs(NS.settings) do
        if setting.cvar then NS.Apply(setting) end
    end
end

function NS.RestartGraphics()
    ConsoleExec("gxRestart")
end

events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == addonName then
        PanoramaDB = type(PanoramaDB) == "table" and PanoramaDB or {}
        local db = PanoramaDB
        if type(db.values) ~= "table" then db.values = {} end
        if db.applyOnLogin == nil then db.applyOnLogin = true end
        for _, setting in ipairs(NS.settings) do
            if setting.cvar then
                db.values[setting.cvar] = NS.Sanitize(setting, db.values[setting.cvar])
            end
        end
        NS.db = db
        if NS.BuildOptions then NS.BuildOptions() end
    elseif event == "PLAYER_LOGIN" then
        -- Le menu Graphismes du jeu peut écraser ces CVars : on les réécrit à chaque connexion.
        if NS.db.applyOnLogin then NS.ApplyAll() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
        if pending then
            pending = false
            NS.ApplyAll()
        end
    end
end)

SLASH_PANORAMA1 = "/pano"
SLASH_PANORAMA2 = "/panorama"
SlashCmdList.PANORAMA = function(message)
    local command = strtrim(message or ""):lower()
    if command == "apply" then
        NS.ApplyAll()
        print("|cff5fd3f0Panorama|r : réglages appliqués.")
    elseif command == "restart" then
        NS.RestartGraphics()
    elseif NS.OpenOptions then
        NS.OpenOptions()
    end
end
