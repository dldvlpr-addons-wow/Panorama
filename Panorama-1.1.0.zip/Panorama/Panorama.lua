-- Panorama : liste des réglages, sauvegarde et écriture des CVars.
-- Le panneau d'options est dans Options.lua.
local addonName, NS = ...

-- Une ligne sans `cvar` est un titre de section.
-- Les bornes min/max sont celles des menus du jeu : le panneau ne permet pas d'en sortir,
-- et une valeur hors bornes dans PanoramaDB (fichier édité à la main) est ramenée dedans.
-- Une CVar inconnue du client est ignorée : ni affichée, ni écrite.
-- `levels` : valeurs des préréglages, dans l'ordre de NS.presets. Sans `levels`, un préréglage
-- ne touche pas au réglage (caméra, souris, confort).
NS.settings = {
    { title = "Distance d'affichage" },
    { cvar = "farclip", label = "Distance des décors", min = 185, max = 2600, step = 5, default = 1300, levels = { 400, 800, 1300, 2600 },
      tip = "Distance d'affichage maximale des décors et structures." },
    { cvar = "horizonfarclip", label = "Distance de l'horizon", min = 1000, max = 5000, step = 8, default = 2112, levels = { 1304, 1704, 2112, 5000 },
      tip = "Distance d'affichage de la ligne d'horizon et du relief." },
    { cvar = "volumeFog", label = "Brouillard volumétrique", default = false, levels = { false, false, true, true },
      tip = "Décoché : supprime le brouillard pour une clarté totale." },

    { title = "Végétation et détails" },
    { cvar = "detailDoodleDensity", label = "Détails au sol", min = 0, max = 100, step = 1, default = 100, levels = { 25, 50, 75, 100 },
      tip = "Densité des petits détails au sol." },
    { cvar = "groundEffectDensity", label = "Densité de l'herbe", min = 16, max = 256, step = 8, default = 256, levels = { 32, 96, 160, 256 },
      tip = "Densité de l'herbe et de la végétation." },
    { cvar = "groundEffectDist", label = "Distance de l'herbe", min = 0, max = 300, step = 5, default = 140, levels = { 40, 80, 140, 300 },
      tip = "Distance de visibilité de la végétation." },

    { title = "Ombres et lumière" },
    { cvar = "shadowLevel", label = "Qualité des ombres", min = 0, max = 2, step = 1, default = 2, levels = { 0, 1, 2, 2 },
      tip = "Qualité des ombres portées." },
    { cvar = "shadowSoft", label = "Ombres adoucies", default = true, levels = { false, false, true, true },
      tip = "Adoucissement réaliste des bords d'ombres." },
    { cvar = "shadowTextureSize", label = "Résolution des ombres", choices = { 1024, 2048 }, default = 2048, levels = { 1024, 1024, 2048, 2048 },
      tip = "Résolution des cartes d'ombres." },
    { cvar = "sunShafts", label = "Rayons de soleil", min = 0, max = 2, step = 1, default = 2, levels = { 0, 1, 2, 2 },
      tip = "Rayons de soleil à travers le décor (God Rays)." },
    { cvar = "SSAO", label = "Occlusion ambiante", min = 0, max = 3, step = 1, default = 3, levels = { 0, 1, 2, 3 },
      tip = "Ombres de contact réalistes (SSAO)." },
    { cvar = "SSFX", label = "Effets d'écran", default = true, levels = { false, true, true, true },
      tip = "Post-traitement avancé (Screen Space Effects)." },

    { title = "Environnement" },
    { cvar = "waterDetail", label = "Détail de l'eau", min = 0, max = 3, step = 1, default = 3, levels = { 0, 1, 2, 3 },
      tip = "Physique et reflets de l'eau." },
    { cvar = "skyCloudLod", label = "Détail du ciel", min = 0, max = 3, step = 1, default = 3, levels = { 0, 1, 2, 3 },
      tip = "Rendu des nuages et du ciel." },
    { cvar = "WeatherDensity", label = "Intensité météo", min = 0, max = 3, step = 1, default = 3, levels = { 0, 1, 2, 3 },
      tip = "Intensité des effets météo (pluie, neige)." },
    { cvar = "physicsLevel", label = "Physique", min = 0, max = 2, step = 1, default = 2, levels = { 0, 1, 2, 2 },
      tip = "Interaction des objets et des tissus." },

    { title = "Image" },
    { cvar = "gxMultisample", label = "Anticrénelage (MSAA)", choices = { 1, 2, 4, 8 }, default = 8, levels = { 1, 1, 4, 8 },
      tip = "Lissage des contours. Prend effet après redémarrage du moteur graphique." },
    { cvar = "ResampleAlwaysSharpen", label = "Filtre de netteté", default = true,
      tip = "Filtre de netteté de l'image." },
    { cvar = "ResampleSharpness", label = "Intensité de la netteté", min = 0, max = 2, step = 0.1, default = 0.5,
      tip = "Force du filtre de netteté, quand il est activé." },
    { cvar = "ffxGlow", label = "Lueur plein écran", default = true, levels = { false, true, true, true },
      tip = "Effet de lueur (bloom) sur les sources de lumière." },
    { cvar = "ffxDeath", label = "Écran gris à la mort", default = false,
      tip = "Décoché : pas de filtre gris quand ton personnage meurt." },
    { cvar = "violenceLevel", label = "Niveau de violence", min = 0, max = 5, step = 1, default = 5,
      tip = "Sang et effets d'impact." },
    { cvar = "ProjectedTextures", label = "Textures projetées", default = true, levels = { false, true, true, true },
      tip = "Rendu des textures projetées au sol (sorts, effets)." },
    { cvar = "spellClutter", label = "Alléger les sorts", default = false, levels = { true, false, false, false },
      tip = "Décoché : conserve l'intégralité du rendu visuel des sorts." },

    { title = "Caméra, souris et interface" },
    { cvar = "cameraDistanceMaxZoomFactor", label = "Recul de la caméra", min = 1, max = 2.6, step = 0.1, default = 2.6,
      tip = "Recul maximal de la caméra." },
    -- Maximum imposé par le client : 60 sur retail, 41 sur les clients Classic.
    { cvar = "nameplateMaxDistance", label = "Distance des barres de nom", min = 20,
      max = (WOW_PROJECT_ID == WOW_PROJECT_MAINLINE) and 60 or 41, step = 1, default = 41,
      tip = "Distance à laquelle les barres de nom des unités s'affichent." },
    { cvar = "rawMouseEnable", label = "Souris brute", default = true,
      tip = "Ignore l'accélération de la souris de Windows." },
    { cvar = "screenshotQuality", label = "Qualité des captures", min = 1, max = 10, step = 1, default = 10,
      tip = "Qualité des captures d'écran." },
}

NS.presets = {
    { id = "low", label = "Bas" },
    { id = "medium", label = "Moyen" },
    { id = "high", label = "Élevé" },
    { id = "extra", label = "Extra" },
}

-- Nom de CVar en minuscules -> réglage, pour l'événement CVAR_UPDATE.
local settingsByCVar = {}
for _, setting in ipairs(NS.settings) do
    if setting.cvar then settingsByCVar[setting.cvar:lower()] = setting end
end

local function GetCVarValue(name)
    if C_CVar and C_CVar.GetCVar then return C_CVar.GetCVar(name) end
    return GetCVar(name)
end

local function SetCVarValue(name, value)
    if C_CVar and C_CVar.SetCVar then return C_CVar.SetCVar(name, value) end
    return SetCVar(name, value)
end

function NS.Exists(setting)
    return GetCVarValue(setting.cvar) ~= nil
end

-- Valeur actuelle de la CVar, au type du réglage (booléen ou nombre), non bornée.
local function ReadCVar(setting)
    local raw = GetCVarValue(setting.cvar)
    if type(setting.default) == "boolean" then return raw ~= "0" end
    return tonumber(raw)
end

-- Ramène une valeur lue dans PanoramaDB dans les limites du réglage.
function NS.Sanitize(setting, value)
    if type(setting.default) == "boolean" then
        if type(value) ~= "boolean" then return setting.default end
        return value
    end
    if type(value) ~= "number" or value ~= value then return setting.default end
    if setting.choices then
        for _, choice in ipairs(setting.choices) do
            if choice == value then return value end
        end
        return setting.default
    end
    return math.min(setting.max, math.max(setting.min, value))
end

local pending = false
local events = CreateFrame("Frame")

function NS.Apply(setting)
    if not NS.Exists(setting) then return end
    -- Certaines CVars refusent l'écriture en combat : tout est réappliqué à la sortie du combat.
    if InCombatLockdown() then
        pending = true
        events:RegisterEvent("PLAYER_REGEN_ENABLED")
        return
    end
    local value = NS.db.values[setting.cvar]
    if type(value) == "boolean" then value = value and 1 or 0 end
    SetCVarValue(setting.cvar, tostring(value))
end

function NS.ApplyAll()
    for _, setting in ipairs(NS.settings) do
        if setting.cvar then NS.Apply(setting) end
    end
end

-- Passe par les réglages du panneau quand ils existent, pour que ses contrôles suivent.
function NS.ApplyPreset(index)
    for _, setting in ipairs(NS.settings) do
        if setting.levels and NS.Exists(setting) then
            local value = NS.Sanitize(setting, setting.levels[index])
            local registered = NS.registered and NS.registered[setting.cvar]
            if registered then
                registered:SetValue(value)
            else
                NS.db.values[setting.cvar] = value
                NS.Apply(setting)
            end
        end
    end
    print("|cff5fd3f0Panorama|r : préréglage " .. NS.presets[index].label
        .. " appliqué. L'anticrénelage demande /pano restart.")
end

function NS.RestartGraphics()
    ConsoleExec("gxRestart")
end

events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
local firstRun = false
events:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == addonName then
        firstRun = type(PanoramaDB) ~= "table" or type(PanoramaDB.values) ~= "table"
        PanoramaDB = type(PanoramaDB) == "table" and PanoramaDB or {}
        local db = PanoramaDB
        if type(db.values) ~= "table" then db.values = {} end
        if db.applyOnLogin == nil then db.applyOnLogin = true end
        for _, setting in ipairs(NS.settings) do
            if setting.cvar then
                local value = db.values[setting.cvar]
                -- Premier lancement, ou réapplication coupée : on part des valeurs actuelles du jeu.
                if NS.Exists(setting) and (value == nil or not db.applyOnLogin) then
                    value = ReadCVar(setting)
                end
                db.values[setting.cvar] = NS.Sanitize(setting, value)
            end
        end
        NS.db = db
        if NS.BuildOptions then NS.BuildOptions() end
    elseif event == "PLAYER_LOGIN" then
        -- Réécrit les valeurs de la dernière session, au cas où le jeu les aurait changées entre-temps
        -- (Config.wtf, détection automatique). Premier lancement : les valeurs viennent du jeu, rien à écrire.
        if NS.db.applyOnLogin and not firstRun then NS.ApplyAll() end
        -- Écouté après la réécriture, pour qu'un CVAR_UPDATE du chargement n'écrase pas PanoramaDB.
        self:RegisterEvent("CVAR_UPDATE")
    elseif event == "CVAR_UPDATE" then
        -- Changement venu du menu Graphismes ou de /console : le panneau suit la vraie valeur.
        local setting = NS.db and type(arg1) == "string" and settingsByCVar[arg1:lower()]
        if setting then
            NS.db.values[setting.cvar] = NS.Sanitize(setting, ReadCVar(setting))
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
        if pending then
            pending = false
            NS.ApplyAll()
        end
    end
end)

SLASH_PANORAMA1 = "/pano"
SLASH_PANORAMA2 = "/panorama"
SlashCmdList.PANORAMA = function(message)
    local command = strtrim(message or ""):lower()
    if command == "apply" then
        NS.ApplyAll()
        if InCombatLockdown() then
            print("|cff5fd3f0Panorama|r : réglages appliqués à la fin du combat.")
        else
            print("|cff5fd3f0Panorama|r : réglages appliqués.")
        end
    elseif command == "restart" then
        NS.RestartGraphics()
    elseif command ~= "" then
        for index, preset in ipairs(NS.presets) do
            if preset.id == command then return NS.ApplyPreset(index) end
        end
        print("|cff5fd3f0Panorama|r : commande inconnue. Préréglages : low, medium, high, extra.")
    elseif NS.OpenOptions then
        NS.OpenOptions()
    end
end
